import urllib.request 
import json 
import time




print(" Keyword arguments (1234) ".center(60,"~"))
def checkPassword(user_pin):
    range = 0
    """Function with while loop and if statement to check if password entry is correct, password is passed as a keyword 
    argument"""
    while True:
        range += 1
        user_input= int(input("Enter pin: ")) 
        if user_pin == (user_input):
            print("Unlocked!")
            break
        else:
            print("Incorrect!")  
        if range == 3:
            print('Disabled: No more tries!')
            break
checkPassword(user_pin=2022)
time.sleep(2)

print("\n")
def buffet(kfc_buffet):
    """ Functions: takes list as an argument  """
    print('Hello! Here are the items in your KFC Buffet list;')
    for foods in kfc_buffet:
        print(f'{foods.title()}')
 #sends a list of foods in list 'kfc_buffet' to the function 'buffet()'     
buffet(kfc_buffet=["popcorn chicken","spicy chicken sandwhich","flatbread","chicken shawarma","waffle"])




print("\n")
print(" Keyword arguments **kwargs ".center(60,"~"))
def pizza_archives(**toppings):
    """ Function retrieves multiple fave pizza toppings in Keyword arguments for the different days of the week"""
    print('Fave pizza toppings')
    #'for' loop within the function to access the name-value pairs in toppings 
    for day, topping in toppings.items():
        print(f'On {day} you like to have: {topping.title()}\n')
     
pizza_archives(Monday='Pepperoni',Tuesday='Mushroom',Wednesday='pineapple',Thursday='Extra cheese',Friday='Sausage',Saturday='Black olives',Sunday='Green pepper')




print("\n")
print(" Functions: difference between  **kwargs and *args".center(80,"~"))
"""
*args(Arbitrary Arguments): If one does not know how many arguments that will be passed into a function, 
a '*'can be added before the parameter name in the function definition(def). Basically allows multiple arguments.
**kwargs(Arbitrary Keyword Arguments): If one does not know how many keyword arguments that will be passed into a function, 
a '*'can be added before the parameter name in the function definition(def). Basically allows multiple keyword arguments.

#**kwargs
def pizza_archives(**toppings):
pizza_archives(Monday='Pepperoni',Tuesday='Mushroom',Wednesday='pineapple',Thursday='Extra cheese',Friday='Sausage',Saturday='Black olives',Sunday='Green pepper')
"""
#*args
def toppings_archives(*toppings):
    """ function retrieves stored fave pizza toppings"""
    #use of the iterable unpacking operator, * and sep=',' to unpack into a single assignment statement
    print('The pizza toppings I want today are', *toppings, sep=",")
    
toppings_archives('pepperoni','mushroom','pineapple','extra cheese','sausage','onions','black olives','green pepper.')
